// -------------------------------------------------------------------------

/**
 *  This class contains static methods that implementing sorting of an array of numbers
 *  using different sort algorithms.
 *
 *  @author Aziz
 *  @version HT 2022
 */

class SortComparison {

    /**
     * Sorts an array of doubles using InsertionSort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     * @param a: An unsorted array of doubles.
     * @return array sorted in ascending order.
     *
     */

    static double [] insertionSort (double a[]){
        int m;
        for ( int n =1 ; n< a.length ; n++){
            m=n;
            while(m>0 && a[m-1]>a[m]){
                double temp = a[m];
                a[m]=a[m-1];   // swap
                a[m-1]=temp;
                m =m -1;

            }

        }
        return a;
    }

    /**
     * Sorts an array of doubles using Selection Sort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     * @param a: An unsorted array of doubles.
     * @return array sorted in ascending order
     *
     */
    static double [] selectionSort (double a[]){
        for ( int m = 0;m< a.length-1 ; m++){
            int min = m;
            for(int n = m+1 ; n < a.length ; n++){
                if ( a[n] < a[min])
                    min = n;
                double temp = a[min];  // swap
                a[min] =a[m];
                a[m]= temp;
            }
        }

        return  a;
    }
    /**
     * Sorts an array of doubles using Quick Sort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     * @param a: An unsorted array of doubles.
     * @return array sorted in ascending order
     *
     */
    static double[] quickSort(double a[]) {

        recursivequickSort(a, 0, a.length - 1);
        return a;
    }

    static void recursivequickSort(double[] a, int lo, int hi) {
        if (hi <= lo) {
            return;
        }
        int pivotPos = partition(a, lo, hi);
        recursivequickSort(a, lo, pivotPos - 1);
        recursivequickSort(a, pivotPos + 1, hi);
    }

    static int partition(double[] a, int lo, int hi) {
        int i = lo;
        int j = hi + 1;
        double pivot = a[lo];
        while (true) {
            while (a[++i] < pivot) {
                if (i == hi)
                    break;
            }
            while (a[--j] >= pivot) {
                if (j == lo)
                    break;
            }
            if (i >= j)
                break;
            double temp = a[i];
            a[i] = a[j];
            a[j] = temp;
        }
        a[lo] = a[j];
        a[j] = pivot;
        return j;
    }


    /**
     * Sorts an array of doubles using Merge Sort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     * @param a: An unsorted array of doubles.
     * @return array sorted in ascending order
     *
     */
    /**
     * Sorts an array of doubles using iterative implementation of Merge Sort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     *
     * @param a: An unsorted array of doubles.
     * @return after the method returns, the array must be in ascending sorted order.
     */

    static double[] mergeSortIterative (double a[]) {

        if(a.length > 1)
        {
            int mid = a.length / 2;

            // Split left part
            double[] left = new double[mid];
            for(int i = 0; i < mid; i++)
            {
                left[i] = a[i];
            }

            // Split right part
            double[] right = new double[a.length - mid];
            for(int i = mid; i < a.length; i++)
            {
                right[i - mid] = (int) a[i];
            }
            mergeSortIterative(left);
            mergeSortIterative(right);

            int i = 0;
            int j = 0;
            int k = 0;

            // Merge left and right arrays
            while(i < left.length && j < right.length)
            {
                if(left[i] < right[j])
                {
                    a[k] = left[i];
                    i++;
                }
                else
                {
                    a[k] = right[j];
                    j++;
                }
                k++;
            }
            // Collect remaining elements
            while(i < left.length)
            {
                a[k] = left[i];
                i++;
                k++;
            }
            while(j < right.length)
            {
                a[k] = right[j];
                j++;
                k++;
            }
        }
        return a;
    }

    /**
     * Sorts an array of doubles using recursive implementation of Merge Sort.
     * This method is static, thus it can be called as SortComparison.sort(a)
     *
     * @param a: An unsorted array of doubles.
     * @return after the method returns, the array must be in ascending sorted order.
     *
     */
    static double[] mergeSortRecursive (double[] a) {
        double[] aux = new double[a.length];
        recursivemergeSort(a, aux, 0, a.length - 1);
        return a;
    }

    private static void recursivemergeSort (double[] a, double[] aux, int lo, int hi) {
        if(hi <= lo)
            return;;
        int mid = lo + (hi-lo)/2;
        recursivemergeSort(a, aux, lo, mid);
        recursivemergeSort(a, aux, mid+1, hi);
        merge(a, aux, lo, mid, hi);
    }

    private static void merge (double[] a, double[] aux, int lo, int mid, int hi) {
        for (int x = lo; x <= hi; x++)
            aux[x] = a[x];

        int i = lo, j = mid+1;
        for(int k = lo; k <= hi; k++) {
            if (i > mid)
                a[k] = aux[j++];
            else if (j > hi)
                a[k] =aux[i++];
            else if (aux[j] < aux[i])
                a[k] = aux[j++];
            else
                a[k] = aux[i++];
        }
    }
















//    public static void main(String[] args) {
//        double[] array = {5, 7, 8, 3};
//        double[] arrayb= {5, 7, 8, 3};
//        double[] arrayc= {5, 7, 8, 3};
//        double[] arrayd= {5, 7, 8, 3};
//        double[] arraye= {5, 7, 8, 3};
//
//
//        array = insertionSort(array);
//        arrayb = selectionSort(arrayb);
//        arrayc = quickSort(arrayc);
//        arrayd = mergeSortIterative(arrayd);
//        arraye =mergeSortRecursive(arraye);
//
//        for ( int i =0 ; i<array.length; i++){
//            System.out.print("insertion sort : " );
//            System.out.println(array[i] + ", \n");
//        }
//        for ( int i =0 ; i<arrayb.length; i++){
//            System.out.print("selection sort : " );
//            System.out.println(arrayb[i] + ", \n");
//        }
//        for ( int i =0 ; i<arrayc.length; i++){
//            System.out.print("quick sort : " );
//            System.out.println(arrayc[i] + ", \n");
//        }
//        for ( int i =0 ; i<arrayd.length; i++){
//            System.out.print(" merger Iterative sort : " );
//            System.out.println(arrayd[i] + ", \n");
//        }
//        for ( int i =0 ; i<arraye.length; i++){
//            System.out.print(" merger recursive sort : " );
//            System.out.println(arraye[i] + ", \n");
//        }
//
//    }
//

}//end class

