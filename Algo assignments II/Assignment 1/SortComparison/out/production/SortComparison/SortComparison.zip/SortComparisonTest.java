// results are in microseconds :


// Insertion :
// 1000 random : 3358
// 1000 few unique : 324
// 1000 nearly ordered :132
// 1000 reverse order :488
// 100 sorted :1
// 10000 random :24580
// ___________________________________________________________________________
// Selection :
// 1000 random : 4325
// 1000 few unique :2962
// 1000 nearly ordered :1911
// 1000 reverse order :949
// 100 sorted :117
// 10000 random :159663
//------------------------------------------------------------------------------
// Quick :
// 1000 random :294
// 1000 few unique :88
// 1000 nearly ordered :134
// 1000 reverse order :489
// 100 sorted :278
// 10000 random :676
// ___________________________________________________________________________
// Merge Recursive  :
// 1000 random :499
// 1000 few unique :148
// 1000 nearly ordered :130
// 1000 reverse order :136
// 100 sorted :68
// 10000 random :1122
// ___________________________________________________________________________
// Merge Iterative  :
// 1000 random :404
// 1000 few unique :121
// 1000 nearly ordered :79
// 1000 reverse order :50
// 100 sorted :33
// 10000 random :35
// ___________________________________________________________________________

//a. Which of these sorting algorithms does the order of input have an impact on? Why?
// insertion sort , as you can see when it was 1000 sorted it took it 1 ms to sort but when it was 1000 random
// it took 3358 ms to sort them  as it takes the min time ( Order of N ) when elements are already sorted and max time
// when elements are sorted randomly or in reverse order

//        b. Which algorithm has the biggest difference between the best and worst performance, based
//        on the type of input, for the input of size 1000? Why?
//
//        c. Which algorithm has the best/worst scalability, i.e., the difference in performance time
//        based on the input size? Please consider only input files with random order for this answer.
//        insertion sort as it took it 1 ms to sort the sorted 1000 and 3358 to sort the random 1000 which is
//         3358 - 1 = 3357 , as I said before insertion sort takes min time when the elements are already sorted and max
//         when they are not
//        d. Did you observe any difference between iterative and recursive implementations of merge
//        sort?
//         yes , Merge Iterative took less time to sort the elements
//        e. Which algorithm is the fastest for each of the 7 input files?
//        Merge Iterative
//



import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

//-------------------------------------------------------------------------
/**
 *  Test class for SortComparison.java
 *
 *  @author
 *  @version HT 2020
 */
@RunWith(JUnit4.class)
public class SortComparisonTest
{
    //~ Constructor ........................................................
    @Test
    public void testConstructor()
    {
        new SortComparison();
    }

    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check that the methods work for empty arrays
     */
    @Test
    public void testEmpty()
    {
        double[] emptyArray = {};
        assertEquals("Checking insertionSort for an empty array", emptyArray, SortComparison.insertionSort(emptyArray));
        assertEquals("Checking selectionSort for an empty array", emptyArray, SortComparison.selectionSort(emptyArray));
        assertEquals("Checking quickSort for an empty array", emptyArray, SortComparison.quickSort(emptyArray));
        assertEquals("Checking mergeSort for an empty array", emptyArray, SortComparison.mergeSortIterative(emptyArray));
        assertEquals("Checking mergeSort for an empty array", emptyArray, SortComparison.mergeSortRecursive(emptyArray));

    }

    @Test
    public void checkArray(){
        double[] a = { 7, 4, 6, 3, 2, 8 };
        assertEquals(" insertion sort ", "[2.0, 3.0, 4.0, 6.0, 7.0, 8.0]",
                Arrays.toString(SortComparison.insertionSort(a)));
        double[] a1 = { 1, 2, 3, 4, 5, 6 };
        assertEquals(" insertion sort ", "[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]",
                Arrays.toString(SortComparison.insertionSort(a1)));
        double[] a2 = {6};
        assertEquals(" insertion sort ", "[6.0]",
                Arrays.toString(SortComparison.insertionSort(a2)));
        double[] a3 = {8,2};
        assertEquals(" insertion sort ", "[2.0, 8.0]",
                Arrays.toString(SortComparison.insertionSort(a3)));


        double[] b = { 9, 8, 7, 6, 5 };
        assertEquals("selection sort ", "[5.0, 6.0, 7.0, 8.0, 9.0]",
                Arrays.toString(SortComparison.selectionSort(b)));
        double[] b1 = { 1, 2, 3, 4, 5, 6 };
        assertEquals(" insertion sort ", "[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]",
                Arrays.toString(SortComparison.selectionSort(b1)));
        double[] b2 = {6};
        assertEquals(" insertion sort ", "[6.0]",
                Arrays.toString(SortComparison.selectionSort(b2)));
        double[] b3 = {8,2};
        assertEquals(" insertion sort ", "[2.0, 8.0]",
                Arrays.toString(SortComparison.selectionSort(b3)));

        double[] c = { 8, 4, 5, 5, 7, 9, 2, 8, 2, 1 };
        assertEquals(" quick sort  ", "[1.0, 2.0, 2.0, 4.0, 5.0, 5.0, 7.0, 8.0, 8.0, 9.0]",
                Arrays.toString(SortComparison.quickSort(c)));
        double[] c1 = { 1, 2, 3, 4, 5, 6 };
        assertEquals(" insertion sort ", "[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]",
                Arrays.toString(SortComparison.quickSort(c1)));
        double[] c2 = {6};
        assertEquals(" insertion sort ", "[6.0]",
                Arrays.toString(SortComparison.quickSort(c2)));
        double[] c3 = {8,2};
        assertEquals(" insertion sort ", "[2.0, 8.0]",
                Arrays.toString(SortComparison.quickSort(c3)));


        double[] d = { 6, 5, 4, 6, 9, 3, 3, 1, 2, 1 };
        assertEquals(" merge sort iterative ", "[1.0, 1.0, 2.0, 3.0, 3.0, 4.0, 5.0, 6.0, 6.0, 9.0]",
                Arrays.toString(SortComparison.mergeSortIterative(d)));
        double[] d1 = { 1, 2, 3, 4, 5, 6 };
        assertEquals(" insertion sort ", "[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]",
                Arrays.toString(SortComparison.mergeSortIterative(d1)));
        double[] d2 = {6};
        assertEquals(" insertion sort ", "[6.0]",
                Arrays.toString(SortComparison.mergeSortIterative(d2)));
        double[] d3 = {8,2};
        assertEquals(" insertion sort ", "[2.0, 8.0]",
                Arrays.toString(SortComparison.mergeSortIterative(d3)));

        double[] e = { 8, 8, 6, 6, 9, 7, 7, 1, 2, 1 };
        assertEquals(" merge sort recursive ", "[1.0, 1.0, 2.0, 6.0, 6.0, 7.0, 7.0, 8.0, 8.0, 9.0]",
                Arrays.toString(SortComparison.mergeSortRecursive(e)));
        double[] e1 = { 1, 2, 3, 4, 5, 6 };
        assertEquals(" insertion sort ", "[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]",
                Arrays.toString(SortComparison.mergeSortIterative(e1)));
        double[] e2 = {6};
        assertEquals(" insertion sort ", "[6.0]",
                Arrays.toString(SortComparison.mergeSortIterative(e2)));
        double[] e3 = {8,2};
        assertEquals(" insertion sort ", "[2.0, 8.0]",
                Arrays.toString(SortComparison.mergeSortIterative(e3)));


    }






    // ----------------------------------------------------------
    /**
     *  Main Method.
     *  Use this main method to create the experiments needed to answer the experimental performance questions of this assignment.
     *
     */

    public static void main(String[] args) {

        File file1 = new File("numbers1000.txt");
        double[] a = new double[1000];
        int j = 0;
        Scanner sc;
        try {
            sc = new Scanner(file1);
            if (sc.hasNextLine()) {
                do {
                    a[j] = Double.parseDouble(sc.nextLine());
                    j++;
                } while (sc.hasNextLine());
            }

            double[] insertion;
            insertion = Arrays.copyOf(a, a.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(insertion);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 random, (insertion sort): " + finalTime / 1000 );

            double[] selection;
            selection = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(selection);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 random, (selection sort): " + finalTime / 1000);

            double[]quick;
            quick = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(quick);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 random, (quick sort): " + finalTime / 1000 );

            double[]MergeI;
            MergeI = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(MergeI);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 random, (merge sort) iterative) : " + finalTime / 1000 );

            double[] MergeR;
            MergeR = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 random, (merge sort recursive) : " + finalTime / 1000 );


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File file2 = new File("numbers1000Duplicates.txt");
        double[] b = new double[1000];
        j = 0;
        try {
            sc = new Scanner(file2);
            if (sc.hasNextLine()) {
                do {
                    b[j] = Double.parseDouble(sc.nextLine());
                    j++;
                } while (sc.hasNextLine());
            }

            double[] Insertion2;
            Insertion2 = Arrays.copyOf(b, b.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(Insertion2);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 few unique, insertion sort: " + finalTime / 1000);

            double[] Selection2;
            Selection2 = Arrays.copyOf(b, b.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(Selection2);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 few unique, selection sort: " + finalTime / 1000 );

            double[] Quick2;
            Quick2 = Arrays.copyOf(b, b.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(Quick2);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 few unique, quick sort: " + finalTime / 1000 );

            double[] MergeI2;
            MergeI2 = Arrays.copyOf(b, b.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(MergeI2);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 few unique, merge sort iterative : " + finalTime / 1000 );

            double[] MergeR2;
            MergeR2 = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR2);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 few unique, merge sort recursive : " + finalTime / 1000 );


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File file3 = new File("numbersNearlyOrdered1000.txt");
        double[] c;
        c = new double[1000];
        j = 0;
        try {
            sc = new Scanner(file3);
            if (sc.hasNextLine()) {
                do {
                    c[j] = Double.parseDouble(sc.nextLine());
                    j++;
                } while (sc.hasNextLine());
            }

            double[] Insertion3;
            Insertion3 = Arrays.copyOf(c, c.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(Insertion3);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 nearly ordered, insertion sort: " + finalTime / 1000 );

            double[] Selection3;
            Selection3 = Arrays.copyOf(c, c.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(Selection3);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 nearly ordered, selection sort: " + finalTime / 1000 );

            double[] Quick3;
            Quick3 = Arrays.copyOf(c, c.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(Quick3);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 nearly ordered, quick sort: " + finalTime / 1000 );

            double[] MergeI3;
            MergeI3 = Arrays.copyOf(c, c.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(MergeI3);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 nearly ordered, merge sort iterative : " + finalTime / 1000 );

            double[] MergeR3 = Arrays.copyOf(a, a.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR3);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 nearly ordered , merge sort recursive : " + finalTime / 1000 );


        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File file4 = new File("numbersReverse1000.txt");
        double[] d = new double[1000];
        j = 0;
        try {
            sc = new Scanner(file4);
            while (sc.hasNextLine()) {
                d[j] = Double.parseDouble(sc.nextLine());
                j++;
            }

            double[] Insertion4;
            Insertion4 = Arrays.copyOf(d, d.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(Insertion4);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 reverse order, insertion sort: " + finalTime / 1000 );

            double[] selection4;
            selection4 = Arrays.copyOf(d, d.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(selection4);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 reverse order, selection sort: " + finalTime / 1000 );

            double[] quick4;
            quick4 = Arrays.copyOf(d, d.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(quick4);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 reverse order, quick sort: " + finalTime / 1000 );

            double[] MergeI4;
            MergeI4 = Arrays.copyOf(d, d.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(MergeI4);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 reverse order, merge sort: " + finalTime / 1000 );

            double[] MergeR4;
            MergeR4 = Arrays.copyOf(d, d.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR4);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 reverse order, merge sort: " + finalTime / 1000 );





        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File file5 = new File("numbersSorted1000.txt");
        double[] e = new double[1000];
        j = 0;
        try {
            sc = new Scanner(file5);
            if (sc.hasNextLine()) {
                do {
                    e[j] = Double.parseDouble(sc.nextLine());
                    j++;
                } while (sc.hasNextLine());
            }

            double[] Insertion5;
            Insertion5 = Arrays.copyOf(e, e.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(Insertion5);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 sorted, insertion sort: " + finalTime / 1000 );

            double[] selection5;
            selection5 = Arrays.copyOf(e, e.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(selection5);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 sorted, selection sort: " + finalTime / 1000 );

            double[] quick5;
            quick5 = Arrays.copyOf(e, e.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(quick5);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 sorted, quick sort: " + finalTime / 1000);

            double[] MergeI5;
            MergeI5 = Arrays.copyOf(e, e.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(MergeI5);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 sorted, merge sort: " + finalTime / 1000 );

            double[] MergeR5;
            MergeR5 = Arrays.copyOf(e, e.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR5);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("1000 sorted, merge sort: " + finalTime / 1000 );


        } catch (FileNotFoundException f1) {
            f1.printStackTrace();
        }

        File file6 = new File("numbers10000.txt");
        double[] f = new double[10000];
        j = 0;
        try {
            sc = new Scanner(file6);
            if (sc.hasNextLine()) {
                do {
                    f[j] = Double.valueOf(sc.nextLine());
                    j++;
                } while (sc.hasNextLine());
            }

            double[] Insertion6;
            Insertion6 = Arrays.copyOf(f, f.length);
            long timeFirst = System.nanoTime();
            SortComparison.insertionSort(Insertion6);
            long finalTime = System.nanoTime() - timeFirst;
            System.out.println("10000 random, insertion sort: " + finalTime / 1000 );

            double[] selection6;
            selection6 = Arrays.copyOf(f, f.length);
            timeFirst = System.nanoTime();
            SortComparison.selectionSort(selection6);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("10000 random, selection sort: " + finalTime / 1000);

            double[] quick6;
            quick6 = Arrays.copyOf(f, f.length);
            timeFirst = System.nanoTime();
            SortComparison.quickSort(quick6);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("10000 random, quick sort: " + finalTime / 1000 );

            double[] mergeI6;
            mergeI6 = Arrays.copyOf(f, f.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortIterative(mergeI6);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("10000 random, merge sort: " + finalTime / 1000 );

            double[] MergeR6;
            MergeR6 = Arrays.copyOf(e, e.length);
            timeFirst = System.nanoTime();
            SortComparison.mergeSortRecursive(MergeR6);
            finalTime = System.nanoTime() - timeFirst;
            System.out.println("10000 random, merge sort: " + finalTime / 1000 );


        } catch (FileNotFoundException f1) {
            f1.printStackTrace();
        }

    }

}